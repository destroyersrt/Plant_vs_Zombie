package application;


import javafx.animation.AnimationTimer;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.Timer; 
import java.util.TimerTask; 

class Example {
    public static int i=0;
}

class Helper extends TimerTask 
{ 		
	public static int i = 0; 
    public void run() 
    { 
        System.out.println("Timer ran" + ++i);
        if(i == 5) 
        { 
            synchronized(driverclass.timer_obj) 
            { 
            	driverclass.timer_obj.notify(); 
            } 
        } 
    } 
} 

public class driverclass
{
	Timer timer = new Timer(); 
	TimerTask task = new Helper(); 
	Helper second = new Helper();
	
	public static driverclass timer_obj= new driverclass();
	
	@FXML
	public ImageView normal_zombie,normal_zombie1,normal_zombie11,normal_zombie111,normal_zombie1111,peeshoot,pea,sun,sun1;
	
	@FXML
	public ImageView sunflower_card,peashooter_card,potato_card;
	
	@FXML
	public ImageView grid1,grid2,grid3,grid4;
    
	@FXML
    public void ExitButton(){
        System.exit(0);
    }
    
    @FXML
    public void Loadmainscreen()
    {
    	try
    	{
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Mainscreen.fxml"));
    		Parent root = (Parent) fxmlLoader.load();
    		Stage stage = new Stage();
    		stage.setTitle("Mainscreen");
    		stage.setScene(new Scene(root));  
    		stage.show();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }
    
    
    @FXML
    public void Loadgame()
    {
    	try
    	{
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Gameplay.fxml"));
    		Parent root = (Parent) fxmlLoader.load();
    		Stage stage = new Stage();
    		stage.setTitle("Mainscreen");    		 		
    		stage.setScene(new Scene(root));  
    		stage.show();	
    		
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }
    
    @FXML
    public void dragdetected(MouseEvent event)
    {
    	System.out.println("Drag detected");
    	event.consume();
    }
    
    @FXML
    public void dragenterted()
    {
    	System.out.println("Drag entered");
    }
    
    @FXML
    public void dragover()
    {
    	System.out.println("Drag over");
    }
    
    @FXML
    public void dragdroopped()
    {
    	System.out.println("Drag dropped");
    }
    
    @FXML
    public void dragdone()
    {
    	System.out.println("Drag done");
    }
    
    @FXML
    public void dragexit()
    {
    	System.out.println("Drag exit");
    }
    
    @FXML
    public void handle()
    {
    	sunflower_card.setOpacity(0.1);
    	System.out.println("changing opacity "); 
    	timer.schedule(task, 0, 1000);
    }
    
//    @FXML
//    public void ghhandle(ActionEvent event)
//    {
//    	FadeTransition fade = new FadeTransition();
//    	fade.setDuration(Duration.millis(10000));
//    	fade.setFromValue(0.1);
//   	fade.setToValue(10);
//    	fade.setNode(sunflower_card);
//    	fade.play();
//    }
    
    @FXML
    public void moveZombie() 
    {
    	
    	normal_zombie.setX(0);
    	normal_zombie.setFocusTraversable(true);
		
    	normal_zombie1.setX(0);
    	normal_zombie1.setFocusTraversable(true);
		
    	normal_zombie11.setX(0);
    	normal_zombie11.setFocusTraversable(true);
		
    	normal_zombie111.setX(0);
    	normal_zombie111.setFocusTraversable(true);
		
    	normal_zombie1111.setX(0);
    	normal_zombie1111.setFocusTraversable(true);
		
    	
		AnimationTimer timer = new AnimationTimer() {
			
			@Override
			public void handle(long now) 
			{
			
				normal_zombie.setX(normal_zombie.getX() - 0.05);
				normal_zombie1.setX(normal_zombie.getX() - 0.05);
				normal_zombie11.setX(normal_zombie.getX() - 0.05);
				normal_zombie111.setX(normal_zombie.getX() - 0.05);
				normal_zombie1111.setX(normal_zombie.getX() - 0.05);
			}
		};
		timer.start();
    }

    @FXML
    public void getPeeShooter() 
    {
    	System.out.println("hi there");
    	
    	sun.setY(0);
    	
    	sun1.setY(0);
    	
    	peeshoot.setX(0);
    	peeshoot.setFocusTraversable(true);
    	
    	FadeTransition fade = new FadeTransition(Duration.millis(5000),peashooter_card);
    	fade.setFromValue(0.2);
    	fade.setToValue(1.0);
    	fade.play();
    	
    	FadeTransition fade2 = new FadeTransition(Duration.millis(5000),sunflower_card);
    	fade2.setFromValue(0.2);
    	fade2.setToValue(1.0);
    	fade2.play();
    	
    	FadeTransition fade3 = new FadeTransition(Duration.millis(5000),potato_card);
    	fade3.setFromValue(0.2);
    	fade3.setToValue(1.0);
    	fade3.play();
    	
    	pea.setX(10);
    	pea.setFocusTraversable(true);
    	
    	AnimationTimer timer = new AnimationTimer() {
    		@Override
    		public void handle(long now) 
    		{
    			pea.setX(pea.getX() + 0.5);    			
    			sun.setY(sun.getY() + 0.1);
    			sun1.setY(sun.getY() + 0.08);
    		}
    	};
    	timer.start();    	
    }

    @FXML
    public void collectSun() 
    {
    	sun.setY(0);
   
    }
    
    @FXML
    public void collectSun1() 
    {
    	sun1.setY(0);
   
    }
    @FXML 
    public void openIngamemenu()
    {
    	try
    	{
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Ingame.fxml"));
    		Parent root = (Parent) fxmlLoader.load();
    		Stage stage = new Stage();
    		stage.setTitle("In Game Menu");    		 		
    		stage.setScene(new Scene(root));  
    		stage.show();	
    		
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	
    	
    }
    
    @FXML 
    public void levelChoose()
    {
    	try
    	{
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("levelChoose.fxml"));
    		Parent root = (Parent) fxmlLoader.load();
    		Stage stage = new Stage();
    		stage.setTitle("Levels");    		 		
    		stage.setScene(new Scene(root));  
    		stage.show();	
    		
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	
    	
    }

}






